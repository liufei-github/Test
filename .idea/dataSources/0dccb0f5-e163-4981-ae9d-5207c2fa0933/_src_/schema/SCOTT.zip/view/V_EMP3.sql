CREATE VIEW V_EMP3 AS select * from stud s inner join classes c on s.classno=c.cno
/
