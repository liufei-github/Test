CREATE VIEW V_EMP AS select  empno,ename,job from  newemp
/
