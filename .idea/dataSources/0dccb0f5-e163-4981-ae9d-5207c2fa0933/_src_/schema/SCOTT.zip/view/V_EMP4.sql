CREATE VIEW V_EMP4 AS select "STUNO","STUNAME","BIRTH","CLASSNO","SEX","HEIGHT" from stud s
with read only
/
