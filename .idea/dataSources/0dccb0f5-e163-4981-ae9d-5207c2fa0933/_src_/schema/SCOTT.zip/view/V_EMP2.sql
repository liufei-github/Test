CREATE VIEW V_EMP2 AS select "EMPNO","ENAME","JOB","MGR","HIREDATE","SAL","COMM","DEPTNO" from newemp where sal>2000 with check option
/
